package myservlet.control;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class testDB {
    public static void main(String[] args) throws SQLException {
        //连接数据库
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sc", "system", "wang");
            Statement sql = conn.createStatement();
            ResultSet rs = sql.executeQuery("SELECT * FROM VISIT");
            if (rs.next()) {
                System.out.println(rs.getString(1));
                System.out.println(rs.getString(2));
                System.out.println(rs.getString(3));
                System.out.println(rs.getString(4));
                System.out.println(rs.getTimestamp(5));
                System.out.println("连接成功");
            }
            else {
                System.out.println("连接失败");
            }
            
        } catch (Exception e) {
        }
    }
}
