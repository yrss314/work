package myservlet.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import mybean.data.SearchBean;

/**
 *
 * @author 萨塔妮亚大喵喵
 */
@WebServlet(name = "SearchServlet1", urlPatterns = {"/SearchServlet1"})
public class SearchServlet extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");   //解决乱码所必须的
        HttpSession ss = request.getSession(true);
        
        String id = request.getParameter("id");
        boolean flag = true;
        try {
            if(id.length() > 0){//不为空则查询，否则直接显示全部结果
                PreparedStatement ps = null;
                ResultSet rs;
//                String regex = "^[0-9]+$";
//                if(id.matches(regex)){//如果是数字则是查询身份证号或学号
                    if(id.length() == 8){
                        ps = DB.dbCon().prepareStatement("select * from studentw where sno = ?");
                        flag = true;
                    }else if(id.length() == 18){
                        ps = DB.dbCon().prepareStatement("select * from renter where id_number = ?");
                        flag = false;
                    }else{
                        RequestDispatcher dis = request.getRequestDispatcher("empty.jsp");
                        dis.forward(request, response);
                    }
//                }
                ps.setString(1, id);
                rs = ps.executeQuery();
                
                if(rs.next()){//如果查询成功
                    SearchBean result = new SearchBean();
                    ss.setAttribute("SearchBean", result);
                    
                    result.setId(rs.getString(1));
                    result.setName(rs.getString(2));
                    result.setFlag(flag);
                    
                    RequestDispatcher dis = request.getRequestDispatcher("DormManagementResult.jsp");
                    dis.forward(request, response);
                    
                }
                //否则显示查无此人
                RequestDispatcher dis = request.getRequestDispatcher("empty.jsp");
                dis.forward(request, response);
            
            }
            else{
                RequestDispatcher dis = request.getRequestDispatcher("DormManagement.jsp");
                dis.forward(request, response);
            }
        } catch (SQLException ex) {
                Logger.getLogger(SearchServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
