package myservlet.control;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class FormatTimestamp {
    public String format(Timestamp timestamp) {
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日 hh时mm分ss秒");
		return format.format(calendar.getTime());
	}
}
