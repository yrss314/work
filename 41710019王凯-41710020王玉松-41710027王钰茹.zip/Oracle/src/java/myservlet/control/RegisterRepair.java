package myservlet.control;

import mybean.data.Repair;
import java.util.Date;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Administrator
 */
public class RegisterRepair extends HttpServlet {

        /**
     *
     * @param config
     * @throws ServletException
     */
    @Override
    public void init(ServletConfig config) throws ServletException{
        super.init(config);
    }
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RegisterRepair</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet RegisterRepair at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        Repair repair = new Repair();
        HttpSession session = request.getSession(true);
        session.setAttribute("repair", repair);
        
        String pno = (String)session.getAttribute("pno");
//        String pno = request.getParameter("pno");
        String dno = request.getParameter("dno");
        String ID_number = request.getParameter("ID_number");
        String remark = request.getParameter("remark");
//      由日期date转换为timestamp
        Timestamp timestamp = new Timestamp(new Date().getTime());
        
        if (pno != null && pno.length() != 0 && dno != null && dno.length() != 0 && ID_number != null && ID_number.length() != 0) {
        
            //连接数据库
            try {
                Class.forName("oracle.jdbc.driver.OracleDriver");
                Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sc", "system", "wang");
                ResultSet rs = null;
//                Statement sql = conn.createStatement();
                String sql = "INSERT INTO REPAIR(PNO, DNO, ID_NUMBER, REMARK, REPORT_TIME) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, pno);
                ps.setString(2, dno);
                ps.setString(3, ID_number);
                ps.setString(4, remark);
                ps.setTimestamp(5, timestamp);
                
                int executeUpdate = ps.executeUpdate();
//                ResultSet rs = sql.executeQuery("SELECT * FROM VISIT");
//            if (rs.next()) {
//                System.out.println("连接成功");
//            }
//            else {
//                System.out.println("连接失败");
//            }
                response.sendRedirect("repair_registration.jsp");
            
            } catch (Exception e) {
                System.out.println(e);
            }
            
            }
        
        else {
        }//endif
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
