package myservlet.control;

import mybean.data.Repair;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import mybean.data.ResultBean;

public class ViewRepair extends HttpServlet {

    /**
     *
     * @param config
     * @throws ServletException
     */
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (Exception e) {
        }
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ViewRepair</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ViewRepair at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String filter = request.getParameter("filter");
        HttpSession session = request.getSession(true);
        ResultBean resultBean = null;
        try {
            resultBean = (ResultBean) session.getAttribute("resultBean");
            if (resultBean == null) {
                resultBean = new ResultBean();
                session.setAttribute("resultBean", resultBean);
            }
        } catch (Exception e) {
            resultBean = new ResultBean();
            session.setAttribute("resultBean", resultBean);
        }
        //连接数据库
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sc", "system", "wang");
            Statement sql = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = null;
            //filter在此进行筛选
            if (filter.equals("unrepair")) {
                rs = sql.executeQuery("SELECT * FROM REPAIR WHERE REPAIR_TIME IS NULL");
//                    暂时没有进行判断
            } else if (filter.equals("all") || filter.equals("")) {
                rs = sql.executeQuery("SELECT * FROM REPAIR");
            } else {
                rs = sql.executeQuery("SELECT * FROM REPAIR WHERE DNO = " + filter);
            }
//                rs = sql.executeQuery("SELECT * FROM REPAIR");

            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();    //得到结果集的列数
            String[] columnName = new String[columnCount];
            for (int i = 0; i < columnName.length; i++) {
                columnName[i] = metaData.getColumnName(i + 1);
            }
            resultBean.setColumnName(columnName);           //更新javabean数据模型
            rs.last();
            int rowNumber = rs.getRow();
            String[][] tableRecord = resultBean.getTableRecord();
            tableRecord = new String[rowNumber][columnCount];
            rs.beforeFirst();
            int i = 0;
            while (rs.next()) {
                for (int k = 0; k < columnCount; k++) {
                    tableRecord[i][k] = rs.getString(k + 1);
                }
                i++;
            }
            resultBean.setTableRecord(tableRecord);
            conn.close();
            response.sendRedirect("showRepair.jsp");

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
