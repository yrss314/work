package myservlet.control;

import mybean.data.Visitor;
import java.util.Date;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class RegisterVisitor extends HttpServlet {

    /**
     *
     * @param config
     * @throws ServletException
     */
    @Override
    public void init(ServletConfig config) throws ServletException{
        super.init(config);
    }
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RegisterVisitor</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet RegisterVisitor at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        /*
        获得javabean中存储的数据，检验其合法性后存入数据库
        */
        request.setCharacterEncoding("UTF-8");
        Visitor visitor = new Visitor();
        String pno;
        HttpSession session = request.getSession(true);
        session.setAttribute("visitor", visitor);
        pno = (String)session.getAttribute("pno");

//        String pno = request.getParameter("pno");
        String ID = request.getParameter("ID");
        String name = request.getParameter("name");
        String intervieweeID = request.getParameter("intervieweeID");
        String remark = request.getParameter("remark");
//        remark用于记录访客与被访者之间的关系
//      由日期date转换为timestamp
        Timestamp timestamp = new Timestamp(new Date().getTime());
        
        //验证数据的合法性（一个非常庞大的if-else选择语句）
        //仅在满足条件的情况下连接数据库并填写数据，否则返回到错误页面
        if (pno != null && pno.length() != 0 && ID != null && ID.length() != 0 && name != null && name.length() != 0 && intervieweeID != null && intervieweeID.length() != 0 ) {
        
            //连接数据库
            try {
                Class.forName("oracle.jdbc.driver.OracleDriver");
                Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sc", "system", "wang");
//                ResultSet rs = null;
//                Statement sql = conn.createStatement();
                String sql = "INSERT INTO VISIT(PNO, VISITOR_ID, VISITOR_NAME, ENTRY, VISITED_ID, RELATIONSHIP) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, pno);
                ps.setString(2, ID);
                ps.setString(3, name);
                ps.setTimestamp(4, timestamp);
                ps.setString(5, intervieweeID);
                ps.setString(6, remark);
                int executeUpdate = ps.executeUpdate();
//                ResultSet rs = sql.executeQuery("SELECT * FROM VISIT");
//            if (rs.next()) {
//                System.out.println("连接成功");
//            }
//            else {
//                System.out.println("连接失败");
//            }
                response.sendRedirect("visitor_registration.jsp");
            
            } catch (Exception e) {
                System.out.println(e);
            }
            
            }
        
        else {
        }//endif
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
