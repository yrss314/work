package myservlet.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import myservlet.control.DB;

@WebServlet(name = "AllocatDormServlet", urlPatterns = {"/AllocatDormServlet"})
public class AllocateDormServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession ss = request.getSession(true);
        String pno = (String)ss.getAttribute("pno");
        
        String id = request.getParameter("id");
        String dno = request.getParameter("dno");
        PreparedStatement ps,pst = null;
        ResultSet rs = null;
        String bed [] = {"0","0","0","0"};
            try {
                pst = DB.dbCon().prepareStatement("select * from accommodation where dno=?");
                pst.setString(1, dno);
                rs = pst.executeQuery();
                while(rs.next()){
                    bed[Integer.valueOf(rs.getString(4)) - 1] = "1";
                }
                pst = DB.dbCon().prepareStatement("select * from rent where dno=?");
                pst.setString(1, dno);
                rs = pst.executeQuery();
                while(rs.next()){
                    bed[Integer.valueOf(rs.getString(4)) - 1] = "1";
                }
                String bednum = "1";
                for(int i = 0; i < 4; i++){
                    if(bed[i].equals("0")){
                        bednum = i+1+"";
                    }
                }
                
                if(id.length() == 8){
                    ps = DB.dbCon().prepareStatement("insert into accommodation values(?,?,?,?)");
                    ps.setString(1, id);
                    ps.setString(2, pno);
                    ps.setString(3, dno);
                    ps.setString(4, bednum);
                }else{
                    ps = DB.dbCon().prepareStatement("insert into rent (id_number, pno, dno, bed_number, checkin_time) values(?,?,?,?,?)");
                    ps.setString(1, id);
                    ps.setString(2, pno);
                    ps.setString(3, dno);
                    ps.setString(4, bednum);
                    Timestamp timestamp = new Timestamp(new Date().getTime());
                    ps.setTimestamp(5, timestamp);
                }
                
                int flag = ps.executeUpdate();
                if(flag>0){
                    RequestDispatcher dis = request.getRequestDispatcher("AllocateSuccess.jsp?id="+id+"&dno="+dno);
                    dis.forward(request, response);
                }else{
                    RequestDispatcher dis = request.getRequestDispatcher("fales.jsp");
                    dis.forward(request, response);
                }
                
            } catch (SQLException ex) {
                Logger.getLogger(AllocateDormServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
        RequestDispatcher dis = request.getRequestDispatcher("fales_1.jsp");
        dis.forward(request, response);

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
