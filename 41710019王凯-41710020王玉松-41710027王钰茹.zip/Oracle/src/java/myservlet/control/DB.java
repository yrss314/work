package myservlet.control;

import java.sql.Connection;
import java.sql.DriverManager;

public class DB {
    public static Connection dbCon(){
        Connection conn = null;
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sc", "system", "wang");
        }
        catch(Exception e){
            System.out.printf("err");
        };
        return conn;
    }
}
