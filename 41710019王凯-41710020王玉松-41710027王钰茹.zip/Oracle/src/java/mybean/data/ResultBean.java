package mybean.data;

public class ResultBean {
    String[] columnName;            //存放列名
    String[][] tableRecord = null;  //存放查询到的记录
    int pageSize = 10;
    int totalPages = 1;
    int currentPage = 1;
    
    public ResultBean() {
        tableRecord = new String[1][1];
        columnName = new String[1];
    }

    public String[] getColumnName() {
        return columnName;
    }

    public void setColumnName(String[] columnName) {
        this.columnName = columnName;
    }

    public String[][] getTableRecord() {
        return tableRecord;
    }

    public void setTableRecord(String[][] tableRecord) {
        this.tableRecord = tableRecord;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }
    
    
    
}
