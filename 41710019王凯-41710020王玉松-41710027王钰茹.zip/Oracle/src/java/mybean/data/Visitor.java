package mybean.data;

/*
 *   用于传递访客登记表中的数据
 */
public class Visitor {
//    String pno;
    String ID;
    String name;
    String intervieweeID;
    String remark;

//    public String getPno() {
//        return pno;
//    }
//
//    public void setPno(String pno) {
//        this.pno = pno;
//    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIntervieweeID() {
        return intervieweeID;
    }

    public void setIntervieweeID(String intervieweeID) {
        this.intervieweeID = intervieweeID;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
    
    
}
