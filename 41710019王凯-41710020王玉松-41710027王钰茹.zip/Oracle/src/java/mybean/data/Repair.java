package mybean.data;

public class Repair {
    String IDnumber;//报修者证件号
    String dno;     //宿舍号
//    String pno;     //园区号
    String remark;  //备注

    public String getIDnumber() {
        return IDnumber;
    }

    public void setIDnumber(String IDnumber) {
        this.IDnumber = IDnumber;
    }

    public String getDno() {
        return dno;
    }

    public void setDno(String dno) {
        this.dno = dno;
    }

//    public String getPno() {
//        return pno;
//    }
//
//    public void setPno(String pno) {
//        this.pno = pno;
//    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
    
    
}
