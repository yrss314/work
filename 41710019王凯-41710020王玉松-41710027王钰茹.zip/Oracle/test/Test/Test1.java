
package Test;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import myservlet.control.DB;

public class Test1 {
    public static void main(String[] args) throws SQLException {
        PreparedStatement ps = DB.dbCon().prepareStatement("select dno from dorm where pno=1 AND dno not in ( select dno from dorm_ocupy where count_num = 4)");
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            System.out.println(rs.getString(1));
        }
        int i = 1;
        String a = "0";
        a = i + 1 + "";
        System.out.println(a);
    }
}
